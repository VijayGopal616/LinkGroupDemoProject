﻿using AventStack.ExtentReports.Gherkin.Model;
using LinkGroupDemoTests.Hooks;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace LinkGroupDemoTests.StepsBinding
{
    [Binding]
    public class LinkGroupTest : TestBase
    {   
        [When(@"I open the home page")]
        public void WhenIOpenTheHomePage()
        {
            driver.Navigate().GoToUrl("https://www.linkgroup.eu/"); 
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20); 
        }
        
        [Given(@"I have agreed to the cookie policy")]
        public void GivenIHaveAgreedToTheCookiePolicy()
        {
            driver.FindElementById("btnAccept").Click();
        }

        [Given(@"I have opened the home page")]
        public void GivenIHaveOpenedTheHomePage()
        {
            driver.Navigate().GoToUrl("https://www.linkgroup.eu/");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
        }

        [When(@"I search for '(.*)'")]
        public void WhenISearchFor(string p0)
        {
            driver.FindElementById("navbardrop").Click();
            driver.FindElementByXPath("//*[@name='searchTerm']").SendKeys("Leeds");
            driver.FindElementByXPath("//*[@class='btn btn-outline-default my-2 my-sm-0']").Click();

        }

        [Then(@"the search results are displayed")]
        public void ThenTheSearchResultsAreDisplayed()
        {
            IWebElement ActualSearchResults = driver.FindElementByXPath("//*[@id='SearchResults']/h3");

            String text = ActualSearchResults.Text;
            Assert.IsTrue(text.Contains("Leeds"));
        }

        [Then(@"the page is displayed")]
        public void ThenThePageIsDisplayed()
        {
            Assert.AreEqual("Home", driver.Title);
        }
    }
}

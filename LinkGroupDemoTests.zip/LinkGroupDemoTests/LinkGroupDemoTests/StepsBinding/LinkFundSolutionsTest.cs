﻿using LinkGroupDemoTests.Hooks;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace LinkGroupDemoTests.StepsBinding
{
    [Binding]
    public class LinkFundSolutionsTest : TestBase
    {
        [Given(@"I have opened the Found Solutions page")]
        public void GivenIHaveOpenedTheFoundSolutionsPage()
        {
            driver.Navigate().GoToUrl("https://www.linkfundsolutions.co.uk/");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
        }
        
        [When(@"I view Funds")]
        public void WhenIViewFunds()
        {
            driver.FindElementById("navbarDropdown").Click();
        }
        
        [Then(@"I can select the investment managers for (.*) investors")]
        public void ThenICanSelectTheInvestmentManagersForInvestors(string link)
        {
            //User clicks on respective links from funds solutions i.e UK, Swiss & Irish in order to check the link is active.
            driver.FindElementByPartialLinkText(link).Click();

           //After clicking the link ensuring the page title is expected or not
           string InvestmentManagers = driver.Title;
           Assert.IsTrue(InvestmentManagers.Contains(link));

           // Setup for If page title is not matched 
           if (!InvestmentManagers.Contains(link))
            {
              Console.WriteLine("tile is falied");
           }
            
        }
    }
}

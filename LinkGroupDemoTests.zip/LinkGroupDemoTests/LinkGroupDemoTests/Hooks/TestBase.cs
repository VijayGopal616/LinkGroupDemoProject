﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using OpenQA.Selenium.Chrome;
using System;
using System.IO;
using TechTalk.SpecFlow;

namespace LinkGroupDemoTests.Hooks
{
    [Binding]
    public  class TestBase
    {
        #region fields
        public static ChromeDriver driver;
        static AventStack.ExtentReports.ExtentReports extent;
        public static string reportPath = System.IO.Directory.GetParent(@"../../../").FullName
            + Path.DirectorySeparatorChar + "Result"
            + Path.DirectorySeparatorChar + "Result_" + DateTime.Now.ToString("ddMMyyy");
        private static ExtentTest feature;
        private static ExtentTest scenario;
        private static ExtentTest step;
        #endregion

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
            ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(reportPath);
            extent = new AventStack.ExtentReports.ExtentReports();
            extent.AttachReporter(htmlReporter);
        }

        [BeforeFeature]

        public static void BeforeFeature(FeatureContext context)
        {
            feature = extent.CreateTest(context.FeatureInfo.Title);
        }

        [BeforeScenario]    
        public static void initialize(ScenarioContext context)
        {
            scenario = feature.CreateNode(context.ScenarioInfo.Title);
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
        }

        [BeforeStep]
        public static void BeforeStep()
        {
            step = scenario;
        }

        [AfterStep]
        public static void AfterStep(ScenarioContext context)
        {
            if (context.TestError == null)
            {
                step.Log(Status.Pass, context.StepContext.StepInfo.Text);
            }
            else if(context.TestError != null)
            {
                step.Log(Status.Fail, context.StepContext.StepInfo.Text);
            }
        }

        [AfterFeature]
       public static void AfterFeature()
        {
            extent.Flush();
        }

        [AfterScenario]
        public static void TearDown()
        {
            driver.Quit();
            driver.Dispose();
        }    
    }
}
